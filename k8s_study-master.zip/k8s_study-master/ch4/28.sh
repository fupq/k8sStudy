#!/bin/sh

# chrono @ 2022-06

kubectl explain pod.spec.containers.resources

kubectl explain pod.spec.containers.startupProbe
kubectl explain pod.spec.containers.livenessProbe
kubectl explain pod.spec.containers.readinessProbe
