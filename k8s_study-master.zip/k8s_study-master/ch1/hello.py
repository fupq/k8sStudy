# chrono @ 2022-04

# docker run --rm -v `pwd`:/tmp python:alpine python /tmp/hello.py

print("hello")
