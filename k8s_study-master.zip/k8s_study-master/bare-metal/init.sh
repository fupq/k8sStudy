#!/bin/sh

# chrono @ 2022-03

sudo apt update
sudo apt install -y openssh-server
sudo apt install -y git vim tree curl jq

echo "please install docker minikube and others."
