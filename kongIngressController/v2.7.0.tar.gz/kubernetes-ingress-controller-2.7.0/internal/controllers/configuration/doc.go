// Package configuration contains Kubernetes controllers responsible for configuration.konghq.com grouped API types.
package configuration
